// mongo setup
const mongoose = require("mongoose");

const mongoURL = "mongodb+srv://psUser:0000@cluster0.ved1g.mongodb.net/college?retryWrites=true&w=majority"

const connectionOptions = {useNewUrlParser: true, useUnifiedTopology: true}

// add your table schemas
const Schema = mongoose.Schema

const ItemSchema = new Schema({
   item:String,
   rarity:String,
   description:String,
   goldPerTurn:Number
})
const Item = mongoose.model("assignment4", ItemSchema)

// express setup
const express = require("express");
const app = express();
app.use(express.json())
const HTTP_PORT = process.env.PORT || 8080;

//3.insert data into the table
// const i1 = new Item({item: "Magpie", 
//                 rarity:"common",
//                 description: "Gives 9 gold every 4 spins",
//                 goldPerTurn:-1})

// const i2 = new Item({item: "King Midas", 
//                 rarity:"rare",
//                 description: "Adds 1 Gold each turn. Adjacent Gold gives 3x more gold.",
//                 goldPerTurn:2})

// const i3 = new Item({item: "Goose", 
//                 rarity:"common",
//                 description: "Has a 1% chance of adding a Golden Egg",
//                 goldPerTurn:1})     
               
// const i4 = new Item({item: "Bee", 
//                 rarity:"uncommon",
//                 description: "Adjacent Flowers give 2x more gold",
//                 goldPerTurn:1})  

// const i5 = new Item({item: "Golden Egg", 
//                 rarity:"rare",
//                 description: "",
//                 goldPerTurn:3})  

// const i6 = new Item({item: "Cat", 
//                 rarity:"common",
//                 description: "",
//                 goldPerTurn:1})

// const i7 = new Item({item: "Void Stone", 
//                 rarity:"uncommon",
//                 description: "Adjacent empty squares give 1 coin more. Destroys itself if adjacent to 0  empty squares. Gives 8 coins when destroyed",
//                 goldPerTurn:0})

// Item.create([i1,i2,i3,i4,i5,i6,i7]).then(
//     () => {
//         console.log("bulk insert succesful through create")
//     }
// ).catch(
//     (err) => {
//         console.log("Error inserting into db")
//         console.log(err)
//     }
// )

// GET ALL
app.get("/api/items", (req, res) => {
    //1. search the db for items and return them
    Item.find().exec().then(
        (results) => {
            console.log(results)
            res.send(results)
        }

    ).catch(
        (err) => {
            console.log(err)
            res.status(500).send("Error while getting items from db")
        }
    )
})

// INSERT 
app.post("/api/items", (req, res) => {

    console.log("I received this from the client:")
    console.log(req.body)
    
    if("item" in req.body && "rarity" in req.body){
        Item.create(req.body).then(
            (result) => {
                //javascript
                console.log("Create success!")
                console.log(result)
                // express
                res.status(201).send({"msg":"Insert successful!"})
            }
        ).catch(
            (err) => {
                console.log(`Error`)
                console.log(err)
                const msg = {
                    statusCode:500,
                    msg: "Error when getting items from database."
                }
                res.status(500).send(msg)
            }
        )
    }
    else (
        res.send({"msg": "missing rarity/name"})
    )

})

// not found data
// app.get("/api/items/:input", (req,res) => {
//     res.status(404).send({"msg":"Data you are requesting not found"})
// })

// not found data
app.get("/api/:input", (req,res) => {
    res.status(404).send({"msg":"Data you are requesting not found"})
})

//not found data
app.get("/:input", (req,res) => {
    res.status(404).send({"msg":"Data you are requesting not found"})
})

// UPDATE BY ID
app.put("/api/items/:id", (req,res) => {
    res.status(501).send({"msg":"Not implemented"})
})

// FIND BY NAME
app.get("/api/items/:item", (req,res) => {

    Item.findOne({item:req.params.item}).exec().then(
        (value) => {
                    if (value === null){
                        console.log("No results found")
                        const msg = {
                            statusCode:404,
                            msg:"No results found"
                        }
                        res.status(404).send(msg)
                    }
                    else {
                        console.log(value)
                        res.send(value)
                    }                    
                } 
    ).catch(
        //when there is a problem with the query
    (error) => {
        console.log(error)
    }
    )
})

//DELETE BY NAME
app.delete("/api/items/:item", (req,res) => {

    Item.findOneAndDelete({item:req.params.item}).exec().then(
        (valueDelete) => {
                    if (valueDelete === null){
                        console.log("No results found")
                        const msg = {
                            statusCode:404,
                            msg:"No results found"
                        }
                        res.status(404).send(msg)
                    }
                    else {
                        console.log(valueDelete)
                        res.send(valueDelete)
                    }                    
                } 
    ).catch(
    (error) => {
        console.log(error)
    }
    )
})

// start server
const onHttpStart = () => {
    console.log(`Server has started and is listening on port ${HTTP_PORT}`)
}

//connect to db
// after you successfully connect, then you start the express server
mongoose.connect(mongoURL, connectionOptions).then(
    () => {
         console.log("connection success")
         app.listen(HTTP_PORT, onHttpStart); 
    }
 ).catch(
    (err) => {
        console.log("Error connecting to database")
        console.log(err)
    }
 )
 
 
 

